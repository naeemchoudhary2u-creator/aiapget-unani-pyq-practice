# Specification

## Summary
**Goal:** Make the "Start Quiz" button in the "Browse by Year" section visually consistent with the "Start Quiz" button in the "Browse by Topic" section.

**Planned changes:**
- In `TopicBrowserScreen.tsx`, copy the background color, text color, border, and hover/active styles from the "Start Quiz" button in the "Browse by Topic" section and apply them to the equivalent quiz launch button in the "Browse by Year" section.

**User-visible outcome:** Both the "Browse by Topic" and "Browse by Year" sections display quiz buttons with identical styling, giving the page a consistent look.
